#!/usr/bin/env python3
"""
空白毕业典礼 - Choice.py
游戏选择引擎
从 git commit 读取内容
"""

import json
import os
import sys
import subprocess
from pathlib import Path

GAME_DIR = Path(__file__).parent
STATE_FILE = GAME_DIR / ".state.json"


def load_state():
    if STATE_FILE.exists():
        with open(STATE_FILE, "r", encoding="utf-8") as f:
            return json.load(f)
    return {
        "current_node": "node_01",
        "current_branch": "main",
        "history": [],
        "visited_nodes": [],
    }


def save_state(state):
    with open(STATE_FILE, "w", encoding="utf-8") as f:
        json.dump(state, f, ensure_ascii=False, indent=2)


def git_show(ref, file_path):
    """Read file content from a git tag/ref"""
    result = subprocess.run(
        ["git", "show", f"{ref}:{file_path}"],
        cwd=GAME_DIR,
        capture_output=True,
        encoding="utf-8",
        errors="replace",
    )
    if result.returncode == 0:
        return result.stdout
    return ""


def git_checkout(ref):
    """Checkout a specific commit or branch"""
    result = subprocess.run(
        ["git", "checkout", ref],
        cwd=GAME_DIR,
        capture_output=True,
        encoding="utf-8",
        errors="replace",
    )
    return result.returncode == 0


if sys.platform == "win32":
    import io

    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")
    sys.stdin = io.TextIOWrapper(sys.stdin.buffer, encoding="utf-8", errors="replace")


def load_current_node(state):
    """Load current node data from git commit"""
    node_id = state.get("current_node", "node_01")
    # node_id is already like "node_01", so use it directly as the tag name
    tag_name = node_id

    scene = git_show(tag_name, "Scene.md")
    story = git_show(tag_name, "Story.md")
    note = git_show(tag_name, "Note.md")
    choices_str = git_show(tag_name, "choices.json")

    try:
        choices = json.loads(choices_str) if choices_str else []
    except json.JSONDecodeError:
        choices = []

    return {
        "node_id": node_id,
        "scene": scene,
        "story": story,
        "note": note,
        "choices": choices,
    }


def display_node(node_data):
    print()
    print("=" * 60)
    print(f"【{node_data.get('node_id', '?')}】")
    print("=" * 60)
    print()

    scene = node_data.get("scene", "")
    if scene:
        print(scene)

    print()

    story = node_data.get("story", "")
    if story:
        print(story)


def show_choices(choices):
    print()
    print("你会怎么做？")
    print()

    for i, choice in enumerate(choices, 1):
        print(f"  [{i}] {choice['text']}")

    print()


def parse_target(target):
    if target == "END":
        return (None, "END")

    if ":" in str(target):
        parts = str(target).split(":", 1)
        return (parts[0], parts[1])
    return (None, str(target))


def handle_choice(choice_num, choices, state):
    if choice_num < 1 or choice_num > len(choices):
        print("无效的选择。")
        return None

    choice = choices[choice_num - 1]
    target = choice["target"]

    if target == "END":
        print()
        print("=" * 60)
        print("感谢游玩《空白毕业典礼》")
        print("=" * 60)
        print()
        print("一个关于记忆、失去和重新开始的故事。")
        print()
        print("也许，下次再见。")
        print()
        return None

    target_branch, target_node = parse_target(target)

    if target_branch:
        state["current_branch"] = target_branch
        git_checkout(target_branch)

    state["current_node"] = target_node
    state["history"].append(target_node)
    state["visited_nodes"].append(target_node)

    return target_node


def display_status():
    state = load_state()
    print(f"当前节点: {state['current_node']}")
    print(f"当前分支: {state['current_branch']}")
    if state["history"]:
        print(f"历史: {' -> '.join(state['history'][-5:])}")


def main():
    state = load_state()

    if len(sys.argv) > 1:
        if sys.argv[1] == "--status":
            display_status()
            return
        elif sys.argv[1] == "--goto" and len(sys.argv) > 2:
            target = sys.argv[2]
            target_branch, target_node = parse_target(target)
            if target_branch:
                state["current_branch"] = target_branch
                git_checkout(target_branch)
            state["current_node"] = target_node
            state["history"].append(target_node)
            state["visited_nodes"].append(target_node)
            save_state(state)
            print(f"已跳转到: {target}")
            return
        elif sys.argv[1] == "--choice" and len(sys.argv) > 2:
            try:
                choice_num = int(sys.argv[2])
                node_data = load_current_node(state)
            except ValueError:
                print("无效的选择数字。")
                return
        else:
            print("用法: python Choice.py [--status] [--goto <node>] [--choice <num>]")
            return
    else:
        node_data = load_current_node(state)

        if not node_data:
            print("无法加载节点数据。")
            return

        display_node(node_data)
        show_choices(node_data.get("choices", []))

        try:
            choice_num = int(input("请输入你的选择: "))
        except ValueError:
            print("请输入有效的数字。")
            return

    result = handle_choice(choice_num, node_data.get("choices", []), state)

    if result:
        save_state(state)
        print(f"\n→ 前往: {result}")
        print("=" * 60)


if __name__ == "__main__":
    main()
